#--------------------------------Imports-----------------------------------

import pygame, time
from pygame.locals import *
from sys import exit
from Tkinter import *

#--------------------------------Image Path--------------------------------

cursor1 = 'cursor.png'
bkg1 = 'under.png'
map1280 = 'map1280.png'
dk1_market = 'dk_market.png'
dk2_worlddb = 'dk_worlddb.png'
dk3_attack = 'dk_attack.png'
dk4_manage = 'dk_manage.png'
dk5_bank = 'dk_bank.png'

loading = 'loading.png'

sp_e = 'sp_e.png'
mp_e = 'mp_e.png'
choose = 'choose.png'

global mar_itm
mar_itm = 'mar_itmv1v.png'

area1 = 'area1.png'

marketdock = 'market_dock.png'


#--------------------------------Image Load--------------------------------
#cursors

i_cursor1 = pygame.image.load(cursor1)  #mouse cursor

#backgrounds

i_bkg1 = pygame.image.load(bkg1)        #init screen
i_map1280 = pygame.image.load(map1280)

#Menu item_g

i_sp_e = pygame.image.load(sp_e)
i_mp_e = pygame.image.load(mp_e)
i_choose = pygame.image.load(choose)

#DOCK
i_dk1_market = pygame.image.load(dk1_market)
i_dk2_worlddb = pygame.image.load(dk2_worlddb)
i_dk3_attack = pygame.image.load(dk3_attack)
i_dk4_manage = pygame.image.load(dk4_manage)
i_dk5_bank = pygame.image.load(dk5_bank)

#loading
i_loading = pygame.image.load(loading)

#Market item
i_maritm_v1 = pygame.image.load(mar_itm)
i_marketdock = pygame.image.load(marketdock)

#areas
i_area1 = pygame.image.load(area1)
#--------------------------------Game Var----------------------------------
 #menu items_var

global i_itm1, i_itm2, i_itm3, i_itm4
i_itm1 = None
i_itm2 = None
i_itm3 = None
i_itm4 = None

global started
started = False

loaded = False

inited = False
chy = 200

global mu, md
mu, md = False, True    #determine if choosebar in menu can be moved or no

global itm1_s, itm2_s
itm1_s, itm2_s= True, False    #Menu item, _s for selected

market_in = False




#-------------------------------Function Sets------------------------------

        
        

def menu_choose():
    pass
    
                
    
def playmusic(filename):    #Format OGG only
    pygame.mixer.init()
    pygame.mixer.music.load(filename)
    pygame.mixer.music.play()

def initialize():
    playmusic('initmusic.ogg')
    #time.sleep(4)
    inited = True
    print mar_itm + "from init in uti"

def buy(kind, amount):
    pass




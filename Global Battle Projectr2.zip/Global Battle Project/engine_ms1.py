#TODO:
#----make the manager

#--------------------------------------Import------------------------------
import pygame, time
from pygame.locals import *
from sys import exit
from uti import *

#--------------------------------------Game--------------------------------
pygame.init()

pygame.mouse.set_visible(False)

screen = pygame.display.set_mode((1280,720),0, 32)
pygame.display.set_caption('Global Battle MS1')

initialize()

#------------------------------------Function----------------------------
def marketswitch(operation):
    print 'called'
    global i_maritm_v1
    del i_maritm_v1
    print 'load canceled'
    if operation == 'add':
        print 'step 1'
        global mar_itm
        mar_itm = mar_itm.split('v')
        num_of_pic = mar_itm[1]
        num_of_pic = int(num_of_pic)
        num_of_pic += 1
        if not num_of_pic == 3:
            num_of_pic = str(num_of_pic)
            global mar_itm
            mar_itm = 'mar_itmv' + num_of_pic + 'v.png'
            print 'moving on to next one'
            global i_maritm_v1
            i_maritm_v1 = pygame.image.load(mar_itm)
        else:
            num_of_pic = 1
            num_of_pic = str(num_of_pic)
            global mar_itm
            mar_itm = 'mar_itmv' + num_of_pic + 'v.png'
            print 'moving on to next one'
            global i_maritm_v1
            i_maritm_v1 = pygame.image.load(mar_itm)
    if operation == 'sub':
        print 'step 1'
        global mar_itm
        mar_itm = mar_itm.split('v')
        num_of_pic = mar_itm[1]
        num_of_pic = int(num_of_pic)
        num_of_pic -= 1
        if not num_of_pic == 0:
            num_of_pic = str(num_of_pic)
            global mar_itm
            mar_itm = 'mar_itmv' + num_of_pic + 'v.png'
            print 'moving on to next one'
            global i_maritm_v1
            i_maritm_v1 = pygame.image.load(mar_itm)
        else:
            num_of_pic = 2
            num_of_pic = str(num_of_pic)
            global mar_itm
            mar_itm = 'mar_itmv' + num_of_pic + 'v.png'
            print 'moving on to next one'
            global i_maritm_v1
            i_maritm_v1 = pygame.image.load(mar_itm)
        

        
#----------------------------------GameLoop Start--------------------------
while 1:
    m_events = pygame.event.get()
    for event in m_events:
        if event.type == QUIT:
            exit()
        if not inited:
            if event.type == KEYDOWN:
                if md == True:
                    if event.key == K_DOWN:
                        chy += 150
                        itm1_s = False
                        itm2_s = True
                        md = False
                        mu = True
                elif mu == True:
                    if event.key == K_UP:
                        chy -= 150
                        itm1_s = True
                        itm2_s = False
                        md = True
                        mu = False
                if event.key == K_RETURN:
                    if itm1_s == True:
                        print "Entering single player..."
                        #time.sleep(1)
                        inited = True
                    if itm2_s == True:
                        print "Entering muti player..."

        
                        
                        
        else:
            
            if itm1_s == True:
                inited = True
            if event.type == KEYDOWN:
                if event.key == K_BACKSPACE:
                    print 'Leaving to single player...'
                    market_in = False
                elif event.key == K_m:
                    print "Entering market..."
                    market_in = True
                    
                elif event.key == K_d:
                    print "Entering world database..."
                elif event.key == K_a:
                    print "Entering attack mode..."
                elif event.key == K_o:
                    print "Entering organizer..."
                elif event.key == K_b:
                    print "Entering bank..."
                    
                if market_in:
                    if event.key == K_RIGHT:
                        print "next"
                        
                        marketswitch('add')
                        
                    if event.key == K_LEFT:
                        print "previous"
                        marketswitch('sub')
                    if event.key == K_SPACE:
                        ansbuy = raw_input("Buy Or Not?(y/n)")
                        if ansbuy == 'y':
                            buynum = input("How Many?")
                            buy(kind, buynum)
                    if event.key == K_t:
                        print 'still under dev'
                
    cx, cy = pygame.mouse.get_pos()
    
    #Display____________________________
    if not inited:
        screen.blit(i_bkg1, (0, 0))
        screen.blit(i_choose, (200, chy))
        screen.blit(i_sp_e, (200, 200))
        screen.blit(i_mp_e, (200, 350)) 
    else:
        if itm1_s == True:    #single player
            if not market_in:
                screen.blit(i_map1280, (0, 0))
                screen.blit(i_dk1_market, (0, 640))
                screen.blit(i_dk2_worlddb, (256, 640))
                screen.blit(i_dk3_attack, (512, 640))
                screen.blit(i_dk4_manage, (768, 640))
                screen.blit(i_dk5_bank, (1024, 640))
                screen.blit(i_area1, (107, 107))
            if market_in:
                screen.blit(i_maritm_v1, (0,0))
                screen.blit(i_marketdock, (0,600))
                
                

    screen.blit(i_cursor1, (cx, cy))
    #UPDATE_________________________
    pygame.display.update()
    
    

#Weapon Type and Information
global wp_1, vwp_1, wp_2, vwp_2
wp_1 = 'ground'
vwp_1 = True
wp_2 = 'air'
vwp_2 = True

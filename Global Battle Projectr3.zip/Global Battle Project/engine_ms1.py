#TODO:
#----make the manager

#--------------------------------------Import------------------------------
import pygame, time
from pygame.locals import *
from sys import exit
from uti import *

#--------------------------------------Game--------------------------------
pygame.init()

pygame.mouse.set_visible(False)

screen = pygame.display.set_mode((1280,720), pygame.FULLSCREEN, 32)
pygame.display.set_caption('Global Battle MS1')

initialize()

#------------------------------------Function------------------------------
def marketswitch(operation):
    global i_maritm_v1
    del i_maritm_v1
    if operation == 'add':
        global mar_itm
        mar_itm = mar_itm.split('v')
        num_of_pic = mar_itm[1]
        num_of_pic = int(num_of_pic)
        num_of_pic += 1
        if not num_of_pic == 3:
            num_of_pic = str(num_of_pic)
            global mar_itm
            mar_itm = 'mar_itmv' + num_of_pic + 'v.png'   #pic change
            global info_mar_itm
            info_mar_itm = 'mar_itmv' + num_of_pic + 'v.txt' #info file change
            info_mar_itm = open(info_mar_itm, 'r')
            global i_maritm_v1
            i_maritm_v1 = pygame.image.load(mar_itm)
        else:
            
            num_of_pic = 1
            num_of_pic = str(num_of_pic)
            global mar_itm
            mar_itm = 'mar_itmv' + num_of_pic + 'v.png'  #pic change
            global info_mar_itm
            info_mar_itm = 'mar_itmv' + num_of_pic + 'v.txt' #info file change
            info_mar_itm = open(info_mar_itm, 'r')
            global i_maritm_v1
            i_maritm_v1 = pygame.image.load(mar_itm)
    if operation == 'sub':
        global mar_itm
        mar_itm = mar_itm.split('v')
        num_of_pic = mar_itm[1]
        num_of_pic = int(num_of_pic)
        num_of_pic -= 1
        if not num_of_pic == 0:
            num_of_pic = str(num_of_pic)
            global mar_itm
            mar_itm = 'mar_itmv' + num_of_pic + 'v.png'
            global i_maritm_v1
            i_maritm_v1 = pygame.image.load(mar_itm)
        else:
            num_of_pic = 2
            num_of_pic = str(num_of_pic)
            global mar_itm
            mar_itm = 'mar_itmv' + num_of_pic + 'v.png'
            global i_maritm_v1
            i_maritm_v1 = pygame.image.load(mar_itm)
        

        

#--------------------------------GLOBALVAR---------------------------------
Current = ['L_0', None, None, None] 
# |1:Level of menu  |2:Name of L1  |3:Name of L2, |4:Name of L3

#----------------------------------GameLoop Start--------------------------
while 1:
    m_events = pygame.event.get()
    for event in m_events:    #event control
        if event.type == QUIT:
            exit()
        if Current[0] == 'L_0':
            if event.type == KEYDOWN:
                if event.key == K_ESCAPE: #ESC to quit
                    exit()
                if md == True:  #if choose bar can be moved down
                    if event.key == K_DOWN:
                        chy += 150
                        itm1_s = False
                        itm2_s = True
                        md = False
                        mu = True
                elif mu == True: #if choose bar cam be moved up
                    if event.key == K_UP:
                        chy -= 150
                        itm1_s = True
                        itm2_s = False
                        md = True
                        mu = False
                if event.key == K_RETURN: #enter to choose
                    if itm1_s == True:
                        #time.sleep(1)
                        Current[0] = 'L_1'
                    if itm2_s == True:
                        pass

        
                        
                        
        else:
            if itm1_s == True:
                Current[0] = 'L_1'
            if event.type == KEYDOWN:
                if event.key == K_ESCAPE: #ESC to quit
                    exit()
                
                if event.key == K_BACKSPACE:
                    Current[0] = 'L_1'
                    Current[1] = None
                    Current[2] = None
                elif event.key == K_m:
                    print "Entering market..."
                    Current[0] = 'L_2'
                    Current[1] = 'Market'                    
                elif event.key == K_d:
                    print "Entering world database..."
                elif event.key == K_a:
                    print "Entering attack mode..."
                elif event.key == K_o:
                    print "Entering organizer..."
                elif event.key == K_b:
                    print "Entering bank..."
                    
                if Current[1] == 'Market':#----------------------------MARKET
                    if event.key == K_RIGHT:
                        marketswitch('add')
                        
                    if event.key == K_LEFT:
                        marketswitch('sub')
                        
                    if event.key == K_SPACE: #------------------------BuyMenu
                        Current[0] = 'L_3'
                        Current[2] = 'BuyMenu'
                    if Current[2] == 'BuyMenu':
                        if event.key == K_n:
                            Current[0] = 'L_2'
                            Current[2] = None
                        
                    if event.key == K_t:#---------------------Market Type menu
                        if Current[2] == 'TypeMenu':  #if already in type menu, press again will go back to market page
                            Current[2] = None
                        else:
                            Current[0] = 'L_3'
                            Current[2] = 'TypeMenu'
                    if Current[2] == 'TypeMenu':
                        if event.key == K_1:
                            print 'Entering AIR Force'
                            Change_Type('air')
                        if event.key == K_2:
                            print 'Entering GROUND Force'
                            Change_Type('ground')
                        if event.key == K_3:
                            print 'Entering SEA Force'
                        if event.key == K_4:
                            print 'Entering ARMYMAN'
                        if event.key == K_5:
                            print 'Entering Missile and Bomb'
                            
                        
                
    cx, cy = pygame.mouse.get_pos()
    
    #Display____________________________
    if Current[0] == 'L_0':
        screen.blit(i_bkg1, (0, 0))
        screen.blit(i_choose, (200, chy))
        screen.blit(i_sp_e, (200, 200))
        screen.blit(i_mp_e, (200, 350)) 
    else:
        if itm1_s == True:    #single player
            if Current[0] == 'L_1':
                screen.blit(i_map1280, (0, 0))
                screen.blit(i_dk1_market, (0, 640))
                screen.blit(i_dk2_worlddb, (256, 640))
                screen.blit(i_dk3_attack, (512, 640))
                screen.blit(i_dk4_manage, (768, 640))
                screen.blit(i_dk5_bank, (1024, 640))
                screen.blit(i_area1, (107, 107))
            if Current[1] == 'Market':
                screen.blit(i_maritm_v1, (0,0))
                screen.blit(i_marketdock, (0,600))
            if Current[2] == 'TypeMenu':
                screen.blit(i_darken, (0, 0))
                screen.blit(i_m_f_air, (100,100))
                screen.blit(i_m_f_ground, (100, 200))
                screen.blit(i_m_f_sea, (100, 300))
                screen.blit(i_m_f_army, (100, 400))
                screen.blit(i_m_f_mb, (100, 500))
            if Current[2] == 'BuyMenu':
                screen.blit(i_darken, (0, 0))
                screen.blit(i_buymenu, (440, 300))
                

    screen.blit(i_cursor1, (cx, cy))
    #UPDATE_________________________
    time.sleep(0.035)    #Screen Update Frequency
    pygame.display.update()
    
    
